Package mt5b3 provides access to the B3 stock exchange to python programs through Metatrader and some Brazilian brokers
 (XP, Clear,Rico and others...)

It allows access to price data (open, close, high, low) and book data (bid, ask). It also allows order placement!!

