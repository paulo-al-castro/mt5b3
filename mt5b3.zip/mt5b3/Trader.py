# This file is part of the mt5b3 package
#  mt5b3 home: https://github.com/paulo-al-castro/mt5b3
# Author: Paulo Al Castro
# Date: 2020-11-17


class Trader:
    def __init__(self):
        pass

    def setup(self,dbars):
        pass

    def trade(self,dbars):
        pass
    
    def ending(self,dbars):
        pass

 