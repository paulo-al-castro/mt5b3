class Trader:
    def __init__(self):
        pass

    def setup(self,dbars):
        pass

    def trade(self,dbars):
        pass
    
    def ending(self,dbars):
        pass

 