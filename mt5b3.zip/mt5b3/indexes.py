# This file is part of the mt5b3 package
#  mt5b3 home: https://github.com/paulo-al-castro/mt5b3
# Author: Paulo Al Castro
# Date: 2020-11-17

import pandas as pd
# TO DO - conseguir baixar os dados de indices de um site confiavel e parsea-los...

# Para download e dados sobre índices. Consulte:
# http://www.b3.com.br/pt_br/market-data-e-indices/

# Indice Ibovespa - http://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/ibovespa.htm
# Link Composicao da carteira
def getIbovespa():
    ibov=pd.read_csv('ibovespa.csv',delimiter=';')
    return ibov


# Índice Brasil 50 (IBrX 50) - http://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/indice-brasil-50-ibrx-50.htm
# Link Composicao da carteira
def getIbx50():
    ibx50=pd.read_csv('ibrx50.csv',delimiter=';')
    return ibx50
# Índice Brasil 100 (IBrX 100) - http://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/indice-brasil-100-ibrx-100.htm
# Link Composicao da carteira
def getIbrx100():
    ibx=pd.read_csv('ibrx100.csv',delimiter=';')
    return ibx      

def loadIndexComposition(fileName):
    idx=pd.read_csv(fileName,delimiter=';')
    return idx   